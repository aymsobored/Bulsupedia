package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class keepedit extends AppCompatActivity {


    Button save;
    TextView datepick;
    EditText edittitle, editnotes;
    DatePickerDialog datePickerDialog;
    Context c = this;
    int position;
    String title, notes, bday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keepedit);

        initialize();
        listener();

    }

    private void initialize() {

        edittitle = findViewById(R.id.edittitle);
        editnotes = findViewById(R.id.editnotes);
        datepick = findViewById(R.id.editdate);
        save= findViewById(R.id.save);

        if (getIntent().hasExtra("title"))
        {
            title = getIntent().getStringExtra("title");
            notes = getIntent().getStringExtra("notes");
            bday = getIntent().getStringExtra("bday");

            position = getIntent().getIntExtra("position",0);
            edittitle.setText(title);
            editnotes.setText(notes);
            datepick.setText(bday);

        }


    }

    private void listener() {



        // date picker
        datePickerDialog = new DatePickerDialog(c, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dateofmonth) {
                String petsa[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
                datepick.setText(" " +(petsa[month])+" "+dateofmonth+", "+year);
            }
        },2002, 2, 2); // set default
        datepick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // if the filled is empty
                if (edittitle.getText().toString().equals("")||editnotes.getText().toString().equals("")||datepick.getText().toString().equals(""))
                {
                    if(edittitle.getText().toString().equals("")){
                        Toast.makeText(c, "Input Title", Toast.LENGTH_SHORT).show();
                    }
                    else if(editnotes.getText().toString().equals("")){
                        Toast.makeText(c, "Input Notes", Toast.LENGTH_SHORT).show();
                    }
                    else if(datepick.getText().toString().equals("")){
                        Toast.makeText(c, "Input Birthdate", Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    title = edittitle.getText().toString();
                    notes = editnotes.getText().toString();
                    bday = datepick.getText().toString();

                    Intent intent = new Intent();
                    intent.putExtra("title", title);
                    intent.putExtra("notes", notes);
                    intent.putExtra("bday", bday);
                    intent.putExtra("position", position);
                    setResult(3,intent);
                    finish();

                }

            }
        });


    }
}