package com.example.bulsupedia;

public class model {
    private String tv;
    private String tv2;

    model(String tv, String tv2){
        this.tv=tv;
        this.tv2=tv2;



    }



    public String getTv() {
        return tv;
    }

    public String getTv2() {
        return tv2;
    }
}
