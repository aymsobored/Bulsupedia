package com.example.bulsupedia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Loginpage extends AppCompatActivity {
    Context c = this;
    ImageView arrowleft1;
    TextView reg1;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://bulsupedia-default-rtdb.firebaseio.com/");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        initilize();
        listener();
    }

    private void initilize() {

        arrowleft1  = findViewById(R.id.arrowleft);
        reg1  = findViewById(R.id.reg1);

        final Button login1 = findViewById(R.id.login1);
        final  EditText userpass1 = findViewById(R.id.userpass1);
        final  EditText userlog1 = findViewById(R.id.userlog1);

        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String UN = userlog1.getText().toString();
                final String PW = userpass1.getText().toString();
                //declare string to display user input on register page
                Intent p = getIntent();
                Bitmap finalPhoto = (Bitmap) p.getParcelableExtra("photo");
                String FN = p.getStringExtra("firstname");
                String LN = p.getStringExtra("lastname");
                String EADD = p.getStringExtra("email");
                String ADD = p.getStringExtra("address");
                String CON = p.getStringExtra("contactnum");
                String BDAY = p.getStringExtra("birthdate");
                String GEN = p.getStringExtra("gender");

                if (UN.isEmpty() || PW.isEmpty()){
                    Toast.makeText(c, "NOT RECORD FOUND!", Toast.LENGTH_LONG).show();

                }
                else{
                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            if (snapshot.hasChild(UN)){

                                final String getPassword = snapshot.child(UN).child("password").getValue(String.class);

                                if (getPassword.equals(PW)){
                                    Toast.makeText(c, "LOGGED IN SUCCESSFULLY!", Toast.LENGTH_LONG).show();
                                    String str = FN +" "+ LN;
                                    Intent a = new Intent(c,Homepage.class);
                                    a.putExtra("text", str);
                                    a.putExtra("photo", finalPhoto);
                                    a.putExtra("username", UN);
                                    a.putExtra("password", PW);
                                    a.putExtra("firstname", FN);
                                    a.putExtra("lastname", LN);
                                    a.putExtra("email", EADD);
                                    a.putExtra("address", ADD);
                                    a.putExtra("contactnum", CON);
                                    a.putExtra("birthdate", BDAY);
                                    a.putExtra("gender", GEN);
                                    startActivity(a);
                                    finish();
                                }
                                else {
                                    Toast.makeText(c, "WRONG PASSWORD!", Toast.LENGTH_LONG).show();
                                }
                            }
                            else {
                                Toast.makeText(c, "WRONG USERNAME & PASSWORD!", Toast.LENGTH_LONG).show();
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }

            }
        });













    }

    private void listener() {



        arrowleft1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });


        reg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(c);
                builder.setTitle("REGISTRATION!")
                        .setMessage("Redirecting to register tab... Please wait!")
                        .setCancelable(true)
                        .setPositiveButton("PROCEED", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Intent p = new Intent(c,Registerpage.class);
                                startActivity(p);
                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
}