package com.example.bulsupedia;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;


public class Adapter  extends RecyclerView.Adapter<Adapter.ViewHolder>{

    private  List<model> users;
    public Adapter (List<model>userlist){this.users=userlist;}



    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.design,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {

        String titles = users.get(position).getTv();
        String dates = users.get(position).getTv2();
        holder.setData(titles, dates);

    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView title1;
        private final TextView date1;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            title1 = itemView.findViewById(R.id.tv);
            date1 = itemView.findViewById(R.id.tv2);




        }
        public void setData(String titles, String dates) {

            title1.setText(titles);
            date1.setText(dates);



        }
    }
}


