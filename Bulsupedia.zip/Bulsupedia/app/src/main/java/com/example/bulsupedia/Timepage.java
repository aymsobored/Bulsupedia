package com.example.bulsupedia;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.time.Clock;
import java.util.Calendar;

public class Timepage extends AppCompatActivity {
    Context z = this;

    TextView hour;
    ImageView arrowleft8, weather8, info8,map8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timepage);

        initiliaze();
        listener();

    }

    private void initiliaze() {

        arrowleft8 = findViewById(R.id.arrowleft3);
        weather8 = findViewById(R.id.weather);
        info8 = findViewById(R.id.info);
        map8 = findViewById(R.id.map);

        hour = findViewById(R.id.currenthour);

        Calendar calendar = Calendar.getInstance();
        String current_date = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());

        TextView textViewDate = findViewById(R.id.currentdate);
        textViewDate.setText(current_date);
    }


    private void listener() {

        // back arrow onclick

        arrowleft8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();

            }
        });



        // go to info page
        info8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Aboutpage.class);
                startActivity(p);

            }
        });

        // go to mapping page
        map8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Mappingpage.class);
                startActivity(p);

            }
        });

        // go to weather page
        weather8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Weatherpage.class);
                startActivity(p);

            }
        });





    }
}