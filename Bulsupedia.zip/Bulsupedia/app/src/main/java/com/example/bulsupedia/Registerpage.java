package com.example.bulsupedia;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Registerpage extends AppCompatActivity {
    Context x = this;
    ImageView arrowleft2;
//    //EditText datepick, userreg2, passreg2,regpasscon2, fname2, lname2, regemail2, recontact2, regaddress2;
//    RadioGroup radiogroup1;
//    RadioButton female1, male1, others1;
//    Button submit1;

    //take a photo
    public static final int CAMERA_ACTION_CODE = 1;
    Bitmap finalPhoto;
    ImageView imageView2;
//    TextView snap2, datepick;

    // date picker
    DatePickerDialog datePickerDialog;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://bulsupedia-default-rtdb.firebaseio.com/");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerpage);

        initilize();
        listener();
    }

    //result of the camera
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_ACTION_CODE && resultCode == RESULT_OK && data != null){
            Bundle bundle = data.getExtras();
            finalPhoto = (Bitmap) bundle.get("data");
            imageView2.setImageBitmap(finalPhoto);
        }
    }

    private void initilize() {

        //back arrow
        arrowleft2  = findViewById(R.id.arrowleft);

        // edit text
        final TextView datepick = findViewById(R.id.datepick);
        final  EditText userreg2 = findViewById(R.id.userreg2);
        final  EditText passreg2 = findViewById(R.id.passreg2);
        final  EditText regpasscon2 = findViewById(R.id.regpasscon2);
        final  EditText fname2 = findViewById(R.id.fname2);
        final  EditText lname2 = findViewById(R.id.lname2);
        final  EditText regemail2 = findViewById(R.id.regemail2);
        final  EditText recontact2 = findViewById(R.id.recontact2);
        final  EditText regaddress2 = findViewById(R.id.regaddress2);
        final RadioGroup radiogroup1 = findViewById(R.id.radiogroup1);

        //gender
        final RadioButton female1 = findViewById(R.id.female1);
        final RadioButton male1 = findViewById(R.id.male1);
        final RadioButton others1 = findViewById(R.id.others1);

        //capture photo
        final ImageView imageView2 = findViewById(R.id.imageView2);
        final TextView snap2 = findViewById(R.id.snap2); // button to take a picture

        // submit buttons
        final Button submit1 = findViewById(R.id.submit1);

        // date picker
        datePickerDialog = new DatePickerDialog(x, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dateofmonth) {
                String petsa[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
                datepick.setText(" " +(petsa[month])+" "+dateofmonth+", "+year);
            }
        },2002, 2, 2); // set default


        // take a photo button
        snap2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //take a photo
                Intent intent  = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (intent.resolveActivity(getPackageManager()) != null){
                    startActivityForResult(intent, CAMERA_ACTION_CODE);
                }
                else{
                    Toast.makeText(x, "there is no app that support this action", Toast.LENGTH_LONG).show();
                }
            }
        });

        // to get the calendar
        datepick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });


        submit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                final String UN = userreg2 .getText().toString();
                final String PW = passreg2 .getText().toString();
                final String CPW = regpasscon2.getText().toString();
                 final String FN = fname2.getText().toString();
                 final String LN = lname2.getText().toString();
                final String EADD = regemail2.getText().toString();
                final String OGEN = others1.getText().toString();
                final String ADD = regaddress2.getText().toString();
                final String CON = recontact2.getText().toString();

                //For display of all Information
                final String BDAY = datepick.getText().toString();
                final String GEN;

                //To get output of other gender
                if(male1.isChecked()){
                    GEN = "Male";
                }
                else if(female1.isChecked()){
                    GEN = "Female";
                }
                else{
                    GEN = OGEN;
                }
                // THE USER INPUT IS MISSING SOME FIELDS
                if (UN.isEmpty() || PW.isEmpty() || CPW.isEmpty() || FN.isEmpty() || LN.isEmpty() || EADD.isEmpty() || ADD.isEmpty() || CON.isEmpty() || GEN.isEmpty() || BDAY.isEmpty()){
                    Toast.makeText(x, "PLEASE! FILL OUT ALL THE FIELDS", Toast.LENGTH_LONG).show();
                }

                // NOT MATCH PASSWORD
                else if (!PW.equals(CPW)){
                    Toast.makeText(x, "PASSWORD IS NOT MATCHED!", Toast.LENGTH_LONG).show();
                }
                else {

                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            if (snapshot.hasChild(UN)){
                                Toast.makeText(x, "USERNAME IS ALREADY REGISTERED.", Toast.LENGTH_LONG).show();
                                finish();
                            }
                            else{

                                //SENDING DATA TO FIREBASE
                                databaseReference.child("users").child(UN).child("email").setValue(EADD);
                                databaseReference.child("users").child(UN).child("password").setValue(PW);
                                databaseReference.child("users").child(UN).child("firstname").setValue(FN);
                                databaseReference.child("users").child(UN).child("lastname").setValue(LN);
                                databaseReference.child("users").child(UN).child("address").setValue(ADD);
                                databaseReference.child("users").child(UN).child("contactnum").setValue(CON);
                                databaseReference.child("users").child(UN).child("birthdate").setValue(BDAY);
                                databaseReference.child("users").child(UN).child("gender").setValue(GEN);

                                Toast.makeText(x, "USER REGISTERED SUCCESSFULLY.", Toast.LENGTH_LONG).show();
                                Intent p = new Intent(x,Loginpage.class);
                                p.putExtra("photo", finalPhoto);
                                p.putExtra("username", UN);
                                p.putExtra("password", PW);
                                p.putExtra("firstname", FN);
                                p.putExtra("lastname", LN);
                                p.putExtra("email", EADD);
                                p.putExtra("address", ADD);
                                p.putExtra("contactnum", CON);
                                p.putExtra("birthdate", BDAY);
                                p.putExtra("gender", GEN);
                                startActivity(p);
                                finish();
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }







            }
        });







    }

    private void listener() {

        // back arrow onclick
        arrowleft2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });


    }
}