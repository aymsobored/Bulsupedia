package com.example.bulsupedia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Homepage extends AppCompatActivity {
    Context z = this;
    ImageView arrowleft3, weather1, info1,map1,times;
    //DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://bulsupedia-default-rtdb.firebaseio.com/");
    TextView fname1, user1, email1, contact1, address1, bdate1, gender1;
    String GEN, BDAY, CON, ADD, EADD, PW, UN, str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        initialize();
        listener();
    }

    private void initialize() {
        arrowleft3 = findViewById(R.id.arrowleft3);
        weather1 = findViewById(R.id.weather);
        info1 = findViewById(R.id.info);
        map1 = findViewById(R.id.map);
        times = findViewById(R.id.times);

        fname1 = findViewById(R.id.fname1);
        user1 = findViewById(R.id.user1);
        email1 = findViewById(R.id.email1);
        contact1 = findViewById(R.id.contact1);
        address1 = findViewById(R.id.address1);
        bdate1 = findViewById(R.id.bdate1);
        gender1 = findViewById(R.id.gender1);

        Intent receive = getIntent();
        str = receive.getExtras().getString("text");
        UN = receive.getExtras().getString("username");
        PW = receive.getExtras().getString("password");
        EADD = receive.getExtras().getString("email");
        ADD = receive.getExtras().getString("address");
        CON = receive.getExtras().getString("contactnum");
        BDAY = receive.getExtras().getString("birthdate");
        GEN = receive.getExtras().getString("gender");

        fname1.setText(str);
        user1.setText(UN);
        email1.setText(EADD);
        contact1.setText(CON);
        address1.setText(ADD);
        bdate1.setText(BDAY);
        gender1.setText(GEN);




    }

    private void listener() {

        // back arrow onclick
        arrowleft3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(z);
                builder.setTitle("CONFIRM LOGOUT")
                        .setMessage("Are you sure you want to logout?")
                        .setCancelable(true)
                        .setPositiveButton("LOGOUT", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                onBackPressed();
                                finish();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {


                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();



            }
        });


        // go to info page
        info1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Aboutpage.class);
                startActivity(p);

            }
        });

        // go to mapping page
        map1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Mappingpage.class);
                startActivity(p);

            }
        });

        // go to weather page
        weather1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Weatherpage.class);
                startActivity(p);

            }
        });

        // go to clock page
        times.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Timepage.class);
                startActivity(p);

            }
        });





    }
}