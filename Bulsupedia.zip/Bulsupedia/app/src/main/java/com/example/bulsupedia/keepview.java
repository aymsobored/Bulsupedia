package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class keepview extends AppCompatActivity {


    TextView viewtitle, viewnotes, viewbday;
    Button back;
    String title, notes, bday;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keepview);

        initialization();
        listener();

    }

    private void initialization() {
        viewtitle = findViewById(R.id.viewtitle);
        viewnotes = findViewById(R.id.viewnotes);
        viewbday = findViewById(R.id.viewdate);
        back = findViewById(R.id.back);

    }

    private void listener() {

        // DISPLAY ALL ENTRY PROFILE
        if(getIntent().hasExtra("name"))
        {
            title = getIntent().getStringExtra("title");
            notes = getIntent().getStringExtra("notes");
            bday = getIntent().getStringExtra("bday");

            viewtitle.setText("Title: "+title);
            viewnotes.setText("Notes: "+notes);
            viewbday.setText("Birthday: "+bday);

        }
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                setResult(10,intent);
                finish();
            }
        });

    }
}