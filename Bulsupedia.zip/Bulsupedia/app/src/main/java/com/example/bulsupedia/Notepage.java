package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;
public class Notepage extends AppCompatActivity {

    //int pos;
    Context v = this;

    Adapter adapter;
    RecyclerView recyclerView;
    List<model> users;
    LinearLayoutManager layoutManager;

    // final int ADD_CODE=1, VIEW_CODE=10, EDIT_CODE=11;

    //ImageView delbtn,editbtn,add;

    // hardcoded entry list
  //  ArrayList<String> titlearray, datearray,notearray;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notepage);

        initialization();
        listener();


    }

    @SuppressLint("NotifyDataSetChanged")
    private void initialization() {

        recyclerView=findViewById(R.id.recycleView);
        layoutManager = new LinearLayoutManager(v);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new Adapter(users);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

























//        users = new ArrayList<>();
//        titlearray = new ArrayList<>();
//        datearray = new ArrayList<>();
//        notearray = new ArrayList<>();
//
//
//        titlearray.add("MEETING");
//        datearray.add("2002/06/12");
//        notearray.add("I LOVE YOU!");
//        users.add(new model(titlearray.get(titlearray.size()-1), datearray.get(datearray.size()-1)));
//
//        titlearray.add("EVENT");
//        datearray.add("2002/02/03");
//        notearray.add("I LOVE YOU!");
//        users.add(new model(titlearray.get(titlearray.size()-1), datearray.get(datearray.size()-1)));
//
//
//        titlearray.add("PARTY");
//        datearray.add("2002/07/24");
//        notearray.add("I LOVE YOU!");
//        users.add(new model(titlearray.get(titlearray.size()-1), datearray.get(datearray.size()-1)));
//
//        layoutManager = new LinearLayoutManager(v);
//        layoutManager.setOrientation(rview.VERTICAL);
//        rview.setLayoutManager(layoutManager);
//        adapter = new Adapter(users);
//        rview.setAdapter(adapter);
//        adapter.notifyDataSetChanged();
//
//
//        //find view
//        editbtn = findViewById(R.id.editbtn);
//        delbtn = findViewById(R.id.delbtn);
//        add = findViewById(R.id.add);
    }

//    // to display the add entry in keepadd
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode==2)
//        {
//            if(data.hasExtra("title"))
//            {
//                titlearray.add(data.getStringExtra("title"));
//                datearray.add(data.getStringExtra("date"));
//                notearray.add(data.getStringExtra("note"));
//                users.add(new model(titlearray.get(titlearray.size()-1), datearray.get(datearray.size()-1)));
//                adapter.notifyItemInserted(adapter.getItemCount()-1);
//                rview.scrollToPosition(adapter.getItemCount()-1);
//            }
//
//        }
//        else if (resultCode==3)
//        {
//            if(data.hasExtra("title"))
//            {
//                pos = data.getIntExtra("position",0);
//                titlearray.set(pos, data.getStringExtra("title"));
//                datearray.set(pos,data.getStringExtra("date"));
//                notearray.set(pos,data.getStringExtra("note"));
//                users.add(new model(titlearray.get(titlearray.size()-1), datearray.get(datearray.size()-1)));
//                adapter.notifyItemChanged(pos);
//                rview.scrollToPosition(pos);
//            }
//        }
//    }




    private void listener() {

        users = new ArrayList<>();
        //hardcoded data
        users.add(new model("Meeting!", "May 17, 2023"));
        users.add(new model("Party!", "March 02, 2023"));
        users.add(new model("Event!", "April 15, 2023"));
        users.add(new model("Gala!", "January 01, 2023"));
        users.add(new model("Vacation", "July 24, 2023"));

//        //add notes
//        add.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent add = new Intent(v,keepadd.class);
//                startActivityForResult(add, ADD_CODE);
//            }
//        });
//
//        //MAINACT5
//        adapter.setOnItemClickListener(new Adapter.OnItemClickListener() {
//            @Override
//            public void OnItemClick(int position) {
//                Intent check = new Intent(v, keepview.class);
//
//                check.putExtra("title",titlearray.get(position));
//                check.putExtra("date", datearray.get(position));
//                check.putExtra("note",notearray.get(position));
//                startActivityForResult(check, VIEW_CODE);
//            }
//
//            @Override
//            public void OnEditClick(int position) {
//                Intent edit = new Intent(v, keepedit.class);
//                pos = position;
//                edit.putExtra("title",titlearray.get(position));
//                edit.putExtra("date", datearray.get(position));
//                edit.putExtra("note",notearray.get(position));
//                edit.putExtra("position",pos);
//                startActivityForResult(edit, EDIT_CODE);
//            }
//
//            @Override
//            public void OnDeleteClick(int position) {
//                AlertDialog.Builder builder = new AlertDialog.Builder(v);
//                builder.setTitle("WARNING!!!")
//                        .setMessage("Are you sure? This entry can't be recovered after deleting.")
//                        .setCancelable(true)
//                        .setPositiveButton("Proceed", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                users.remove(position);
//                                adapter.notifyItemRemoved(position);
//                                titlearray.remove(position);
//                                datearray.remove(position);
//                                notearray.remove(position);
//
//                            }
//                        })
//                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//
//                            }
//                        });
//
//                AlertDialog dialog = builder.create();
//                dialog.show();
//            }
//        });

    }
}
