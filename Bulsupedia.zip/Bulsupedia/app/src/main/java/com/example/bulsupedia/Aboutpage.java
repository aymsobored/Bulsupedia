package com.example.bulsupedia;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Aboutpage extends AppCompatActivity {
    Context z = this;
    ImageView arrowleft5, weather2,map2, times1;
    Button vision,  mission, goals, history, aboutbulsu, contactus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutpage);

        initialize();
        listener();
    }

    private void initialize() {
        //menus button
        arrowleft5 = findViewById(R.id.arrowleft4);
        weather2 = findViewById(R.id.weather);
        map2 = findViewById(R.id.map);
        times1 = findViewById(R.id.times);

        //buttons for info about bulsu
        vision = findViewById(R.id.vision);
        mission = findViewById(R.id.mission);
        goals = findViewById(R.id.goals);
        history = findViewById(R.id.history);
        aboutbulsu = findViewById(R.id.aboutbulsu);
        contactus = findViewById(R.id.contactus);


    }

    private void listener() {

        // back arrow onclick
        arrowleft5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });


        // go to mapping page
        map2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Mappingpage.class);
                startActivity(p);

            }
        });

        // go to weather page
        weather2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Weatherpage.class);
                startActivity(p);

            }
        });

        // go to time page
        times1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Timepage.class);
                startActivity(p);

            }
        });

        // on click on the vision
        vision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(z);
                builder.setTitle("                      VISION")
                        .setMessage("\nBulacan State University is a progressive knowledge-generating institution globally recognized for excellent instruction, pioneering research, and responsive community engagements.\n\n")
                        .setCancelable(true)
                        .setPositiveButton("BACK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        // on click on the mission
        mission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(z);
                builder.setTitle("                      MISSION")
                        .setMessage("\nBulacan State University exists to produce highly competent, ethical and service-oriented professionals that contribute to the sustainable socio-economic growth and \ndevelopment of the nation.\n\n")
                        .setCancelable(true)
                        .setPositiveButton("BACK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });


        // on click on the goals
        goals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(z);
                builder.setTitle("                      GOALS")
                        .setMessage("\n• Provide Relevant Quality and Accessible Education\n" +
                                "\n" +
                                "• Innovative and Responsive Research and Public Engagement\n" +
                                "\n" +
                                "• BulSU in Regional Development\n" +
                                "\n" +
                                "• Sound Financial Management\n" +
                                "\n" +
                                "• Good Governance")
                        .setCancelable(true)
                        .setPositiveButton("BACK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        // on click on the bulsu history
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(z);
                builder.setTitle("                 BULSU HISTORY")
                        .setMessage("\nThe Bulacan State University started as an intermediate school in 1904. It was established during the early years Of the American occupation by virtue of Act 74 of the Philippine Commission in 1901, which created the then Department of Public Instruction with the mandate to establish schools in every pueblo of the country and reorganize those already existing. Instructions in the intermediate schools established during that time were supplemented with trade or industrial instruction.")
                        .setCancelable(true)
                        .setPositiveButton("BACK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        // on click on the about bulsu
        aboutbulsu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(z);
                builder.setTitle("                    ABOUT US")
                        .setMessage("\nBULACAN STATE UNIVERSITY (BulSU) is the premiere state-operated institution of higher learning in the Cenral Luzon region. It originated as a secondary school run by the Americans in 1904, and has now progressed into one of the biggest educational institutions in Region III. BulSU was converted from a college into a University in 1993 by virtue of Republic Act 7665. Since then, BulSU has grown by leaps and bounds, in terms of program offerings, faculty qualification, and student enrolment. The University has also maintained the existence of four external campuses within the province namely Meneses Campus, Hagonoy Campus, Sarmiento Campus, and Bustos Campus")
                        .setCancelable(true)
                        .setPositiveButton("BACK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        // on click on the mission
        contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(z);
                builder.setTitle("                    CONTACT US")
                        .setMessage("\n• Location: Guinhawa, City of Malolos, Bulacan   \n" +
                                "\n" +
                                "• Contact No: 919-7800  \n" +
                                "\n" +
                                "• Email: officeofthepresident@bulsu.edu.ph")
                        .setCancelable(true)
                        .setPositiveButton("BACK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });




    }
}