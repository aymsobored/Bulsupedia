package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.github.chrisbanes.photoview.PhotoView;

public class Pimentelpage extends AppCompatActivity {
    Context z = this;
    ImageView arrowleft7, weather4,map3,info3,times6;
    PhotoView pin_f1, pin_f2, pin_f3, pin_f4,bulsu_map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pimentelpage);

        initilize();
        listener();
    }

    private void initilize() {

        //menus button
        arrowleft7 = findViewById(R.id.arrowleft);
        weather4 = findViewById(R.id.weather);
        map3 = findViewById(R.id.map);
        info3 = findViewById(R.id.info);
        times6 = findViewById(R.id.times);

        //bulsu directory map
        bulsu_map = (PhotoView) findViewById(R.id.bulsu_map);

        //pimentel floor
        pin_f1 = (PhotoView) findViewById(R.id.pin_f1);
        pin_f2 = (PhotoView) findViewById(R.id.pin_f2);
        pin_f3 = (PhotoView) findViewById(R.id.pin_f3);
        pin_f4 = (PhotoView) findViewById(R.id.pin_f4);


    }

    private void listener() {

        // back arrow onclick
        arrowleft7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });


        // go to mapping page
        map3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Mappingpage.class);
                startActivity(p);

            }
        });

        // go to weather page
        weather4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Weatherpage.class);
                startActivity(p);

            }
        });

        // go to info page
        info3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Aboutpage.class);
                startActivity(p);

            }
        });

        // go to info page
        times6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Timepage.class);
                startActivity(p);

            }
        });

        //zoom in zoom out code for image
        bulsu_map.setImageResource(R.drawable.bulsu_directory);
        //floor1
        pin_f1.setImageResource(R.drawable.pimintel_1st);
        //floor2
        pin_f2.setImageResource(R.drawable.pimintel_2nd);
        //floor3
        pin_f3.setImageResource(R.drawable.pimintel_3rd);
        //floor4
        pin_f4.setImageResource(R.drawable.pimintel_4th);


    }
}