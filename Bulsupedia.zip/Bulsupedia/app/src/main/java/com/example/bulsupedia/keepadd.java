package com.example.bulsupedia;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class keepadd extends AppCompatActivity {

    Button submit;
    EditText addentrytitle, addentrynotes;
    TextView datepick;
    String title, notes,bday;
    DatePickerDialog datePickerDialog;
    Context c = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keepadd);

        initialize();
        listener();

    }

    private void initialize() {

        submit = findViewById(R.id.submit);
        addentrytitle = findViewById(R.id.title);
        addentrynotes = findViewById(R.id.notes);
        datepick = findViewById(R.id.datepick);

    }



    private void listener() {

        // date picker
        datePickerDialog = new DatePickerDialog(c, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dateofmonth) {
                String petsa[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
                datepick.setText(" " +(petsa[month])+" "+dateofmonth+", "+year);
            }
        },2002, 2, 2); // set default

        datepick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (addentrytitle.getText().toString().equals("")||addentrynotes.getText().toString().equals("")||datepick.getText().toString().equals(""))
                {
                    if(addentrytitle.getText().toString().equals("")){
                        Toast.makeText(keepadd.this, "Input Title", Toast.LENGTH_SHORT).show();
                    }
                    else if(addentrynotes.getText().toString().equals("")){
                        Toast.makeText(keepadd.this, "Input Notes", Toast.LENGTH_SHORT).show();
                    }
                    else if(datepick.getText().toString().equals("")){
                        Toast.makeText(keepadd.this, "Input Birthdate", Toast.LENGTH_SHORT).show();
                    }

                }
                else
                {
                    title = addentrytitle.getText().toString();
                    notes = addentrynotes.getText().toString();
                    bday = datepick.getText().toString();
                    Intent intent = new Intent();
                    intent.putExtra("title", title);
                    intent.putExtra("notes", notes);
                    intent.putExtra("bday", bday);


                    setResult(2,intent);
                    finish();
                }

            }
        });

    }
}