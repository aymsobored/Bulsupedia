package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.github.chrisbanes.photoview.PhotoView;

public class Natividadpage extends AppCompatActivity {

    Context z = this;
    ImageView arrowleft8, weather5,map4,info4,times5;
    PhotoView nat_f1, nat_f2, nat_f3, nat_f4, nat_f5, bulsu_map1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_natividadpage);

        initilize();
        listener();
    }

    private void initilize() {
        //menus button
        arrowleft8 = findViewById(R.id.arrowleft);
        weather5 = findViewById(R.id.weather);
        map4 = findViewById(R.id.map);
        info4 = findViewById(R.id.info);
        times5 = findViewById(R.id.times);

        //bulsu directory map
        bulsu_map1 = (PhotoView) findViewById(R.id.bulsu_map);

        //natividad floor
        nat_f1 = (PhotoView) findViewById(R.id.nat_f1);
        nat_f2 = (PhotoView) findViewById(R.id.nat_f2);
        nat_f3 = (PhotoView) findViewById(R.id.nat_f3);
        nat_f4 = (PhotoView) findViewById(R.id.nat_f4);
        nat_f5 = (PhotoView) findViewById(R.id.nat_f5);



    }

    private void listener() {

        // back arrow onclick
        arrowleft8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });


        // go to mapping page
        map4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Mappingpage.class);
                startActivity(p);

            }
        });

        // go to weather page
        weather5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Weatherpage.class);
                startActivity(p);

            }
        });

        // go to info page
        info4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Aboutpage.class);
                startActivity(p);

            }
        });

        // go to time page
        times5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Timepage.class);
                startActivity(p);

            }
        });

        //zoom in zoom out code for image
        bulsu_map1.setImageResource(R.drawable.bulsu_directory);
        //floor1
        nat_f1.setImageResource(R.drawable.natividad_1st);
        //floor2
        nat_f2.setImageResource(R.drawable.natividad_2nd);
        //floor3
        nat_f3.setImageResource(R.drawable.natividad_3rd);
        //floor4
        nat_f4.setImageResource(R.drawable.natividad_4th);
        //floor5
        nat_f5.setImageResource(R.drawable.natividad_4th);


    }
}