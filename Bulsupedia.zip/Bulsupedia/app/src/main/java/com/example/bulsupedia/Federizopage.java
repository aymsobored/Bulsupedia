package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.github.chrisbanes.photoview.PhotoView;

public class Federizopage extends AppCompatActivity {

    Context z = this;
    ImageView arrowleft9, weather6,map5,info5,times2;
    PhotoView fed_f1, fed_f2, fed_f3, bulsu_map2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_federizopage);

        initilize();
        listener();
    }
    private void initilize() {

        //menus button
        arrowleft9 = findViewById(R.id.arrowleft);
        weather6 = findViewById(R.id.weather);
        map5 = findViewById(R.id.map);
        info5 = findViewById(R.id.info);
        times2 = findViewById(R.id.times);

        //bulsu directory map
        bulsu_map2 = (PhotoView) findViewById(R.id.bulsu_map);

        //federizo floor
        fed_f1 = (PhotoView) findViewById(R.id.fed_f1);
        fed_f2 = (PhotoView) findViewById(R.id.fed_f2);
        fed_f3 = (PhotoView) findViewById(R.id.fed_f3);



    }

    private void listener() {

        // back arrow onclick
        arrowleft9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });


        // go to mapping page
        map5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Mappingpage.class);
                startActivity(p);

            }
        });

        // go to weather page
        weather6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Weatherpage.class);
                startActivity(p);

            }
        });

        // go to info page
        info5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Aboutpage.class);
                startActivity(p);

            }
        });

        // go to times page
        times2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Timepage.class);
                startActivity(p);

            }
        });

        //zoom in zoom out code for image
        bulsu_map2.setImageResource(R.drawable.bulsu_directory);
        //floor1
        fed_f1.setImageResource(R.drawable.federizo_1st);
        //floor2
        fed_f2.setImageResource(R.drawable.federizo_2nd);
        //floor3
        fed_f3.setImageResource(R.drawable.federizo_3rd);




    }
}