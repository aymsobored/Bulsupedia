package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class Weatherpage extends AppCompatActivity {
    Context c = this;
    ImageView arrowleft4, info3, map3,times6;
    EditText searchtemp;
    TextView tmp, wnd1, ph,feel;
    Button btncheck;
    DecimalFormat df = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weatherpage);

        initilize();
        listener();



    }





    private void initilize() {

        arrowleft4  = findViewById(R.id.arrowleft);
        info3  = findViewById(R.id.info);
        map3  = findViewById(R.id.map);
        times6  = findViewById(R.id.times);

        //weather api
        searchtemp  = findViewById(R.id.searchtemp);
        tmp  = findViewById(R.id.tmp);
        btncheck  = findViewById(R.id.btncheck);
        wnd1  = findViewById(R.id.wind1);
        ph  = findViewById(R.id.country1);
        feel  = findViewById(R.id.feel);
    }


    public void get(View view) {
        String apikey = "9aee9cab2c5d272653c9d7a4d2fa4b24";
        String city = searchtemp.getText().toString();
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apikey;

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONObject object = response.getJSONObject("main");
                    String temperature = object.getString("temp");
                    Double temp = Double.parseDouble(temperature)-273.15;
                    String feels_like = object.getString("feels_like");
                    Double temp2 = Double.parseDouble(feels_like)-273.15;

                    JSONObject object1 = response.getJSONObject("wind");
                    String wind = object1.getString("speed");
                    Double temp1 = Double.parseDouble(wind);

                    JSONObject object2 = response.getJSONObject("sys");
                    String country = object2.getString("country");



                    tmp.setText(temp.toString().substring(0,5)+ "°C");
                    feel.setText("FEELS LIKE: " + df.format(temp2).toString() +"°C");
                    wnd1.setText("WIND: " + temp1.toString());
                    ph.setText("COUNTRY: "+country.toString());



                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(c, "CITY NOT FOUND!", Toast.LENGTH_LONG).show();

            }
        });
        queue.add(request);


    }





    private void listener() {

        // back arrow onclick
        arrowleft4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });

        // go to info page
        info3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(c,Aboutpage.class);
                startActivity(p);

            }
        });

        // go to mapping page
        map3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(c,Mappingpage.class);
                startActivity(p);

            }
        });

        // go to mapping page
        times6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(c,Timepage.class);
                startActivity(p);

            }
        });






















    }
}