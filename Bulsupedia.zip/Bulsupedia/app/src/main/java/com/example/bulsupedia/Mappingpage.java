package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Mappingpage extends AppCompatActivity {

    Context z = this;
    ImageView arrowleft6, weather3,info2,times4;
    ImageButton pimentel, natividad, federizo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mappingpage);

        initilize();
        listener();
    }

    private void initilize() {
        //menu
        arrowleft6 = findViewById(R.id.arrowleft);
        weather3 = findViewById(R.id.weather);
        info2 = findViewById(R.id.info);
        times4 = findViewById(R.id.times);

        //halls
        pimentel = findViewById(R.id.pimentel);
        natividad = findViewById(R.id.natividad);
        federizo = findViewById(R.id.federizo);



    }

    private void listener() {

        // back arrow onclick
        arrowleft6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        });


        // go to about page
        info2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Aboutpage.class);
                startActivity(p);

            }
        });

        // go to weather page
        weather3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Weatherpage.class);
                startActivity(p);

            }
        });

        // go to times page
        times4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Timepage.class);
                startActivity(p);

            }
        });

        // go to directory maps

        //on click to pimentel

        pimentel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Pimentelpage.class);
                startActivity(p);

            }
        });

        //on click to natividad

        natividad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Natividadpage.class);
                startActivity(p);

            }
        });

        //on click to natividad

        federizo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(z,Federizopage.class);
                startActivity(p);

            }
        });





    }
}