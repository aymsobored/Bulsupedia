package com.example.bulsupedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Context c = this;
    ImageView arrowright,bulsu_logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initilize();
        listener();
    }



    private void initilize() {

        arrowright  = findViewById(R.id.arrowright);
        bulsu_logo  = findViewById(R.id.bulsu_logo);
    }

    private void listener() {

        bulsu_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(c, "BULACAN STATE UNIVERSITY", Toast.LENGTH_LONG).show();
            }
        });



        arrowright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent p = new Intent(c,Loginpage.class);
                startActivity(p);
            }
        });
    }



}